package com.ubo.apirest.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3306/addcars";
    
    private static final String USER = "emilio"; 
    private static final String PASS = "1234";    

    public static Connection getConexion() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection(URL, USER, PASS);
            
            return con; 

        } catch (ClassNotFoundException e) {
            System.err.println("ERROR: No tienes el JAR de MySQL en las Librerías.");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("ERROR SQL: No se pudo conectar. " + e.getMessage());
            e.printStackTrace();
        }
        return null; 
    }
}