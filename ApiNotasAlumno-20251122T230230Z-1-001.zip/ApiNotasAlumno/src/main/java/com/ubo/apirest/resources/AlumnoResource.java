package com.ubo.apirest.resources;

import com.ubo.apirest.db.Conexion;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import org.json.JSONObject;
import org.json.JSONArray;

@Path("/addcars")
public class AlumnoResource {
    
//OPERACION 1
    
@POST
@Path("/buscarSeguro")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public Response buscarSeguro(JSONObject input) {
    JSONObject result = new JSONObject();
    String idVehiculo; // Declarada aquí para usarla en todo el método

    // --- BLOQUE 1: VALIDACIÓN DEL JSON DE ENTRADA ---
    
    // 1. Validar si el JSONObject de entrada es nulo (El framework podría pasarlo si el body es inválido)
    if (input == null) {
        result.put("error", "El servidor recibió un cuerpo de solicitud vacío o un JSON inválido.");
        return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
    }
    
    // 2. DIAGNÓSTICO: Si la clave no existe, mostramos qué claves SÍ llegaron
    if (!input.has("id_vehiculo")) {
        // Obtenemos la lista de claves que sí llegaron
        String clavesRecibidas = input.keySet().toString();
        
        String mensajeError = "Clave faltante: 'id_vehiculo'. " +
                              "Las claves que detecté son: " + clavesRecibidas;
        
        result.put("error", mensajeError);
        return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
    }
    
    // 3. Intentamos obtener el valor y validar que no esté vacío
    try {
        idVehiculo = input.getString("id_vehiculo");
        if (idVehiculo == null || idVehiculo.trim().isEmpty()) {
             result.put("error", "El campo 'id_vehiculo' no puede estar vacío.");
             return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
        }
    } catch (Exception e) {
        // Captura si el valor existe pero no es un String, por ejemplo.
        result.put("error", "Error al leer el valor de 'id_vehiculo'. Error: " + e.getMessage());
        return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
    }


    // --------------------------------------------------------------------------
    // --- BLOQUE 2: LÓGICA DE BASE DE DATOS ---
    // --------------------------------------------------------------------------
    String sql = "SELECT * FROM seguros WHERE id_vehiculo = ?";

    try (Connection conn = Conexion.getConexion()) {
        if (conn == null) {
            result.put("error", "Error: No hay conexión con la base de datos.");
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result.toString()).build();
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, idVehiculo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // 1. Extraemos TODOS los datos de la tabla 'seguros'
                    result.put("id_vehiculo", rs.getString("id_vehiculo"));
                    result.put("id_seguro", rs.getString("id_seguro"));
                    result.put("compania", rs.getString("compania"));
                    result.put("descripcion", rs.getString("descripcion"));
                    result.put("cobertura", rs.getString("cobertura"));
                    
                    // Las fechas se convierten a String
                    result.put("fecha_inicio", rs.getDate("fecha_inicio").toString());
                    result.put("fecha_fin", rs.getDate("fecha_fin").toString());
                    
                    result.put("costo_anual", rs.getInt("costo_anual"));
                } else {
                    result.put("mensaje", "No se encontró un seguro para el vehículo ID: " + idVehiculo);
                }
            }
        }
    } catch (Exception e) {
        result.put("error", "Error SQL: " + e.getMessage());
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result.toString()).build();
    }

    return Response.ok(result.toString()).build();
}

//OPERACION 2

@PUT
@Path("/actualizarVehiculo")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public Response actualizarVehiculo(JSONObject input) {
    System.out.println("JSON QUE LLEGÓ: " + input.toString());
    JSONObject result = new JSONObject();
   

    // 1. Extracción de datos 
    String id_vehiculo = input.optString("id_vehiculo");
    String id_modelo = input.optString("id_modelo");
    String id_sucursal = input.optString("id_sucursal");
    String id_categoria = input.optString("id_categoria");
    
    int precio_base_dia = input.optInt("precio_base_dia", 0);
    int anio = input.optInt("anio", 0);
    
    String descripcion = input.optString("descripcion");
    String imagen_url = input.optString("imagen_url");

    // 2. Validaciones de campos obligatorios
    if (id_modelo.isEmpty() || id_sucursal.isEmpty() || id_categoria.isEmpty() || id_vehiculo.isEmpty()) {
        result.put("error", "Error: Faltan IDs requeridos (Modelo, Sucursal, Categoría o Vehículo)");
        return Response.ok(result.toString()).build();
    }

    String sql = "UPDATE vehiculos SET " +
                 "id_modelo = ?, " +
                 "precio_base_dia = ?, " +
                 "id_sucursal = ?, " +
                 "descripcion = ?, " +
                 "imagen_url = ?, " +
                 "anio = ?, " +
                 "id_categoria = ? " +
                 "WHERE id_vehiculo = ?";

    // 3. Bloque try-with-resources para conexión y sentencia
    try (Connection con = Conexion.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        // Asignación de parámetros
        ps.setString(1, id_modelo);
        ps.setInt(2, precio_base_dia);
        ps.setString(3, id_sucursal);
        ps.setString(4, descripcion);

        // Manejo de imagen nula
        if (imagen_url == null || imagen_url.trim().isEmpty()) {
            ps.setNull(5, Types.VARCHAR);
        } else {
            ps.setString(5, imagen_url.trim());
        }

        ps.setInt(6, anio);
        ps.setString(7, id_categoria);
        ps.setString(8, id_vehiculo); // ID para el WHERE

        // 4. Ejecución
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas == 1) {
            result.put("mensaje", "Vehículo actualizado correctamente");
            result.put("exito", true);
        } else if (filasAfectadas == 0) {
            result.put("error", "No se encontró el vehículo ID " + id_vehiculo);
            result.put("exito", false);
        } else {
            result.put("error", "Alerta: Se actualizaron múltiples registros. Revisar BD.");
            result.put("exito", false);
        }

    } catch (Exception e) {
        result.put("error", "Error SQL: " + e.getMessage());
        e.printStackTrace();
    }

    return Response.ok(result.toString()).build();
}

//OPERACION 3

@POST
    @Path("/buscarVehiculo")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarVehiculo(JSONObject input) {
        JSONObject result = new JSONObject();

        // 1. Validar que el input tenga el dato necesario
        if (input == null || !input.has("id_vehiculo")) {
            result.put("error", "Debe proporcionar el parámetro 'id_vehiculo'");
            return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
        }

        String idVehiculo = input.getString("id_vehiculo");

        // 2. Consulta SQL para traer todos los campos de la tabla vehiculos
        String sql = "SELECT * FROM vehiculos WHERE id_vehiculo = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, idVehiculo);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // 3. Mapear las columnas de la BD al JSON de respuesta
                    result.put("id_vehiculo", rs.getString("id_vehiculo"));
                    result.put("anio", rs.getInt("anio"));
                    result.put("patente", rs.getString("patente"));
                    result.put("id_categoria", rs.getString("id_categoria"));
                    result.put("id_sucursal", rs.getString("id_sucursal"));
                    result.put("precio_base_dia", rs.getInt("precio_base_dia"));
                    result.put("descripcion", rs.getString("descripcion"));
                    result.put("id_modelo", rs.getString("id_modelo"));
                    
                    // Manejo de posible nulo en imagen_url
                    String imgUrl = rs.getString("imagen_url");
                    result.put("imagen_url", (imgUrl != null) ? imgUrl : JSONObject.NULL);
                    
                    result.put("exito", true);
                } else {
                    result.put("mensaje", "No se encontró ningún vehículo con el ID: " + idVehiculo);
                    result.put("exito", false);
                }
            }

        } catch (Exception e) {
            result.put("error", "Error SQL: " + e.getMessage());
            e.printStackTrace();
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result.toString()).build();
        }

        return Response.ok(result.toString()).build();
    }


//OPERACION 4
    
@POST
@Path("/listarPorSucursal")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public Response listarVehiculos(JSONObject input) {
    JSONObject result = new JSONObject();
    
    // 1. Validar entrada
    if (input == null || !input.has("id_sucursal")) {
        result.put("error", "Debe proporcionar 'id_sucursal'");
        return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
    }
    
    String idSucursal = input.getString("id_sucursal");
    JSONArray listaVehiculos = new JSONArray(); // Aquí guardaremos los autos encontrados

    String sql = "SELECT id_vehiculo, marca.nombre as marca, modelo.nombre_modelo, v.anio, v.precio_base_dia " +
                 "FROM vehiculos v " +
                 "JOIN modelos modelo ON v.id_modelo = modelo.id_modelo " +
                 "JOIN marcas marca ON modelo.id_marca = marca.id_marca " +
                 "WHERE v.id_sucursal = ?";

    try (Connection con = Conexion.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, idSucursal);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                // Por cada fila encontrada, creamos un objeto JSON pequeño
                JSONObject vehiculo = new JSONObject();
                vehiculo.put("id", rs.getString("id_vehiculo"));
                vehiculo.put("marca", rs.getString("marca"));
                vehiculo.put("modelo", rs.getString("nombre_modelo"));
                vehiculo.put("anio", rs.getInt("anio"));
                vehiculo.put("precio", rs.getInt("precio_base_dia"));
                
                // Lo agregamos a la lista
                listaVehiculos.put(vehiculo);
            }
        }
        
        // Verificamos si encontramos algo
        if (listaVehiculos.length() > 0) {
            result.put("vehiculos", listaVehiculos);
            result.put("cantidad", listaVehiculos.length());
            result.put("exito", true);
        } else {
            result.put("mensaje", "No hay vehículos en la sucursal " + idSucursal);
            result.put("exito", false);
        }

    } catch (Exception e) {
        result.put("error", "Error SQL: " + e.getMessage());
        e.printStackTrace();
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result.toString()).build();
    }

    return Response.ok(result.toString()).build();
}
    
//OPERACION 5

@POST
    @Path("/buscarMantenimiento")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarMantenimiento(JSONObject input) {
        JSONObject result = new JSONObject();

        // 1. Validar que venga el ID
        if (input == null || !input.has("id_vehiculo")) {
            result.put("error", "Falta el 'id_vehiculo'");
            return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
        }

        String idVehiculo = input.getString("id_vehiculo");

        // 2. Consulta directa relacionando las tablas por id_vehiculo
        String sql = "SELECT m.id_mantenimiento, m.fecha, m.tipo, m.detalle, m.costo, v.patente " +
                     "FROM mantenimientos m " +
                     "JOIN vehiculos v ON m.id_vehiculo = v.id_vehiculo " +
                     "WHERE m.id_vehiculo = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, idVehiculo);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Al encontrar el registro, llenamos el objeto directamente
                    result.put("id_mantenimiento", rs.getString("id_mantenimiento"));
                    result.put("id_vehiculo", idVehiculo);
                    result.put("patente", rs.getString("patente")); // Dato útil del vehículo
                    result.put("fecha", rs.getDate("fecha").toString());
                    result.put("tipo", rs.getString("tipo"));
                    result.put("detalle", rs.getString("detalle"));
                    result.put("costo", rs.getInt("costo"));
                    
                    result.put("exito", true);
                } else {
                    result.put("mensaje", "No se encontró mantenimiento para el vehículo " + idVehiculo);
                    result.put("exito", false);
                }
            }

        } catch (Exception e) {
            result.put("error", "Error en BD: " + e.getMessage());
            e.printStackTrace();
        }

        return Response.ok(result.toString()).build();
    }
}
